# Continuity Context

- Envelope Schema: [tiinex.root.v1](https://github.com/Tiinex/docs/blob/3988951208eb9a8926e84ab42625d4b42fa00c2d/.topics/.schemas/tiinex.root.v1.schema.md)
- Parent
  - Parent Schema: [tiinex.handoff.package.v1](https://github.com/Tiinex/docs/blob/3988951208eb9a8926e84ab42625d4b42fa00c2d/.topics/.schemas/coordination/handoff/package/tiinex.handoff.package.v1.schema.md)
  - Created At: 1970-01-01 00:00:00
  - Trace: [001-tiinex-handoff-package.trace.md](001-tiinex-handoff-package.trace.md)
  - Origin:
    - [relative](001-tiinex-handoff-package.trace.md)
- Current
  - Current Schema: [tiinex.pointer.v1](https://github.com/Tiinex/docs/blob/3988951208eb9a8926e84ab42625d4b42fa00c2d/.topics/.schemas/core/pointer/tiinex.pointer.v1.schema.md)
  - Created At: 1970-01-01 00:00:00
  - Summary: Qualified recovery/orientation Pointer for the pointerless package-v1 Workspace carrier.

---

# READ BEFORE PROCEEDING — Tiinex Workspace Carrier

Read this Start artifact first and qualify the declared Tooling bootstrap. This carrier intentionally exposes no Handoff route or Continue-from Pointer; do not infer semantic Handoff state from Workspace carriage.

## Current Read

- Carrier Role: recovery-orientation
- Bootstrap Exception: before Tiinex Tooling is available, use host capabilities only to read this entry/bootstrap node and extract the declared bootstrap ZIP into a writable runtime location; do not unpack Workspace payloads or perform package archaeology
- Tooling Entrypoint: `runtime/tools/tiinex-portable.mjs` relative to the chosen bootstrap extraction root; use this exact path and do not search/list the extracted runtime to discover it
- First Tooling Invocation: `node <bootstrap-root>/runtime/tools/tiinex-portable.mjs orient-handoff-package <untouched-workspace-package.zip>`
- Carrier Mode: pointerless Workspace carrier; no Handoff route, Continue-from Pointer, endpoint Role, current work, transfer, acceptance, completion, or participation is declared or inferred
- Route Selection: none; the canonical package role requires Route Placement Rule, Continue-From Rule, and Pre-Handoff Closure Rule to all be exactly `none`
- Next Action: after Tooling orientation, use only the qualified carried Workspace identities and exact Workspace landing/inspection operations required by the consuming workflow
- Fallback: fail closed when Tooling cannot qualify the package role, exact Workspace bindings, bootstrap, or all-none Route Discovery profile; native package archaeology is not a preferred-path substitute
- Package Artifact: [Workspace Package](001-tiinex-handoff-package.trace.md)
- Carrier Dimension: `001`

Transport topology and exact byte-map evidence is carried in the package transport manifest.

## Destinations

- Workspace Package contract: [001-tiinex-handoff-package.trace.md](001-tiinex-handoff-package.trace.md)
- Portable Tooling bootstrap: [001-2-bootstrap.trace.md](001-2-bootstrap.trace.md)
- Workspace acceptance: [001-3-acceptance.workspace.md](001-3-acceptance.workspace.md)

## Interpretation Notes

- Numeric pathing is not generic Tiinex semantic authority. In this Handoff package, the generator deliberately projects the declared package-local Parent lineage into matching numeric pathing for readable random-access traversal.
- Exact carried source artifact bytes and independently verified payload bytes retain their own authority; package-local lineage does not rewrite their historical provenance.

---

# Continuity Integrity

- [sha256-base64url-c14n-v2](https://github.com/Tiinex/docs/blob/3988951208eb9a8926e84ab42625d4b42fa00c2d/.topics/.validators/sha256-base64url-c14n-v2.validator.md)
  - Towards: [001-tiinex-handoff-package.trace.md](001-tiinex-handoff-package.trace.md)
  - Value: 42ahELuuAuDjoresI_IMFmIj6t9S1guZy9qfxhnDVXY

- [sha256-base64url-c14n-v2](https://github.com/Tiinex/docs/blob/3988951208eb9a8926e84ab42625d4b42fa00c2d/.topics/.validators/sha256-base64url-c14n-v2.validator.md)
  - Towards: self
  - Value: GprqGl0MG2SGCi0P0VCuVXso8ovKN5Nko0ejkm4f_Lw
