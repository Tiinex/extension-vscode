# Continuity Context

- Envelope Schema: [tiinex.root.v1](https://github.com/Tiinex/docs/blob/3988951208eb9a8926e84ab42625d4b42fa00c2d/.topics/.schemas/tiinex.root.v1.schema.md)
- Current
  - Current Schema: [tiinex.handoff.package.v1](https://github.com/Tiinex/docs/blob/3988951208eb9a8926e84ab42625d4b42fa00c2d/.topics/.schemas/coordination/handoff/package/tiinex.handoff.package.v1.schema.md)
  - Created At: 1970-01-01 00:00:00
  - Summary: Recipient-facing self-contained carrier identity, Start/bootstrap exposure, qualified source-material bindings, route discovery when declared, and transport projection boundaries.

---

# Handoff Package

## Package Identity

- Package Role: recipient-facing-workspace-carrier
- Carrier Kind: self-contained

## Bootstrap Exposure

- Start Artifact: [Start](001-1-READ-BEFORE-PROCEEDING.trace.md)
- Tooling Bootstrap Descriptor: [Bootstrap](001-2-bootstrap.trace.md)
- Bootstrap Rule: start-then-qualified-bootstrap

## Workspace Snapshot Bindings

- acceptance
  - Workspace Id: acceptance
  - Workspace Artifact: [acceptance Workspace](001-3-acceptance.workspace.md)
  - Snapshot Path: [acceptance Snapshot](001-3-acceptance.workspace.zip)
  - Workspace Artifact Inner Path: `.topics/.workspaces/extension-host-acceptance.workspace.md`
  - Snapshot Kind: exact-workspace-byte-tree-archive
  - Coverage: complete
  - Binding State: verified
  - Integrity Method: sha256
  - Integrity Value: 010713ebb4974d39a39ea4517ff17807f7a51e4808aba3b83bc1c7c098da2d29
  - Byte Size: 19416

## Material Representation Bindings

- none

## Route Discovery

- Route Placement Rule: none
- Continue-From Rule: none
- Pre-Handoff Closure Rule: none

## Transport Projection

- Generic Transport Rule: start-artifact-instruction
- Route Transport Rule: none
- Recipient Projection Rule: none

## Carrier Continuity

- Carrier Dimension: 001
- Carrier Checkpoint: progression
- Carrier Profile Id: none
- Required Major Workspace Ids: none

## Qualification Boundary

- Receiver Qualification: reverify-carried-authority-and-bytes
- Failure Policy: fail-closed
- Derived Inventory Authority: none

## Interpretation Limits

- Does Not Mean: package placement, discovery ancestry, byte integrity, Role presence, Workspace identity, or transport destination creates Handoff, recipient, holder, participation, acceptance, provenance, Parent, project membership, or work authority
- Must Not Be Used To Claim: carrier convenience metadata overrides authoritative contained artifacts, exact qualified source bytes, or the selected Handoff To endpoint when recipient projection is permitted
- Generic Payload Boundary: bootstrap/cache payloads retain explicit External Payload ownership when required; direct complete Workspace snapshot binding is package-local only
- Generic Representation Boundary: independently selectable complete/bounded Workspace representation semantics remain owned by qualified tiinex.workspace.representation.v1 bindings
- Carrier Profile Boundary: required Workspace identifiers come only from the explicit carrier profile; literal project Workspace names have no generic semantic meaning

---

# Continuity Integrity

- [sha256-base64url-c14n-v2](https://github.com/Tiinex/docs/blob/3988951208eb9a8926e84ab42625d4b42fa00c2d/.topics/.validators/sha256-base64url-c14n-v2.validator.md)
  - Towards: self
  - Value: 42ahELuuAuDjoresI_IMFmIj6t9S1guZy9qfxhnDVXY
