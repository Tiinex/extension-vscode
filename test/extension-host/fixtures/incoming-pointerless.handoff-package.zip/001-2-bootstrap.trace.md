# Continuity Context

- Envelope Schema: [tiinex.root.v1](https://github.com/Tiinex/docs/blob/3988951208eb9a8926e84ab42625d4b42fa00c2d/.topics/.schemas/tiinex.root.v1.schema.md)
- Parent
  - Parent Schema: [tiinex.handoff.package.v1](https://github.com/Tiinex/docs/blob/3988951208eb9a8926e84ab42625d4b42fa00c2d/.topics/.schemas/coordination/handoff/package/tiinex.handoff.package.v1.schema.md)
  - Created At: 1970-01-01 00:00:00
  - Trace: [001-tiinex-handoff-package.trace.md](001-tiinex-handoff-package.trace.md)
  - Origin:
    - [relative](001-tiinex-handoff-package.trace.md)
- Current
  - Current Schema: [tiinex.external.payload.v1](https://github.com/Tiinex/docs/blob/3988951208eb9a8926e84ab42625d4b42fa00c2d/.topics/.schemas/external/payload/tiinex.external.payload.v1.schema.md)
  - Created At: 1970-01-01 00:00:00
  - Summary: Qualified package-local payload node for the portable Tooling bootstrap archive.

---

# Portable Tooling Bootstrap Payload

## Payload Identity

- Payload Label: portable Tooling bootstrap runtime
- Payload Kind: zip export
- Media Type: application/zip
- Format: deterministic stored ZIP
- Byte Size: 6044796
- Payload Role: portable Tooling bootstrap runtime for recipient orientation and verification

## Payload Location

- Location: [001-2-bootstrap.zip](001-2-bootstrap.zip)
- Location Type: local
- Access Method: read exact package-local payload bytes after this artifact qualifies
- Storage Boundary: recipient-relative Handoff carrier only

## Integrity Reference

- Integrity Status: verified
- Integrity Method: sha256
- Integrity Value: b24a2b785dea6c9ff5017950cb9d9e3f5ee9881a67206c74b7b8bb20b021a106
- Integrity Target: exact payload bytes as carried at the declared local Location
- Validation Method: independent byte digest plus payload-format qualification

## Access Boundary

- Access Boundary: recipient-local package read
- Publicly Shareable: unknown
- Retention Policy: disposable with this recipient-relative carrier unless separately preserved

## Interpretation Limits

- This artifact owns one package-local payload node. Its Parent is package-local continuity; the ZIP companion cannot carry a Markdown envelope but participates in this node through this artifact.
- Payload integrity does not create Workspace identity, Handoff acceptance, completion, semantic truth, or remote provenance.

## Evidence Basis

Transport topology and exact byte-map evidence is carried in the package transport manifest.

---

# Continuity Integrity

- [sha256-base64url-c14n-v2](https://github.com/Tiinex/docs/blob/3988951208eb9a8926e84ab42625d4b42fa00c2d/.topics/.validators/sha256-base64url-c14n-v2.validator.md)
  - Towards: [001-tiinex-handoff-package.trace.md](001-tiinex-handoff-package.trace.md)
  - Value: 42ahELuuAuDjoresI_IMFmIj6t9S1guZy9qfxhnDVXY

- [sha256-base64url-c14n-v2](https://github.com/Tiinex/docs/blob/3988951208eb9a8926e84ab42625d4b42fa00c2d/.topics/.validators/sha256-base64url-c14n-v2.validator.md)
  - Towards: self
  - Value: GYqpaAo8WaHot6BuHxtiV2eVenN3XUdDrn_6Y1H7T2s
